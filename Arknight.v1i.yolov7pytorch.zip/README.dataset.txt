# Arknight > 2022-11-24 9:39pm
https://universe.roboflow.com/aoobex-z533d/arknight

Provided by a Roboflow user
License: CC BY 4.0

